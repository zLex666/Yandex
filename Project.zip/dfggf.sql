-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 11 2023 г., 23:53
-- Версия сервера: 8.0.19
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `dfggf`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cdelki`
--

CREATE TABLE `cdelki` (
  `id_cdelk` int NOT NULL,
  `kod_client` int NOT NULL,
  `kod_valuts` int NOT NULL,
  `summa` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `cdelki`
--

INSERT INTO `cdelki` (`id_cdelk`, `kod_client`, `kod_valuts`, `summa`) VALUES
(1, 1, 1, 1400),
(2, 1, 2, 7800),
(3, 2, 1, 4200);

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE `clients` (
  `id_client` int NOT NULL,
  `FIO` varchar(30) NOT NULL,
  `numb_pass` int NOT NULL,
  `ser_pass` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `clients`
--

INSERT INTO `clients` (`id_client`, `FIO`, `numb_pass`, `ser_pass`) VALUES
(1, 'Макаров Никита Сергеевич', 4516, 456123),
(2, 'Алексей Третьяков Андреевич', 4315, 345612);

-- --------------------------------------------------------

--
-- Структура таблицы `valuts`
--

CREATE TABLE `valuts` (
  `id_valut` int NOT NULL,
  `name` varchar(30) NOT NULL,
  `kurs_sales` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `valuts`
--

INSERT INTO `valuts` (`id_valut`, `name`, `kurs_sales`) VALUES
(1, 'Доллар', 81),
(2, 'Евро', 89);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cdelki`
--
ALTER TABLE `cdelki`
  ADD PRIMARY KEY (`id_cdelk`),
  ADD KEY `kod_client` (`kod_client`,`kod_valuts`),
  ADD KEY `kod_valuts` (`kod_valuts`);

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id_client`);

--
-- Индексы таблицы `valuts`
--
ALTER TABLE `valuts`
  ADD PRIMARY KEY (`id_valut`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `cdelki`
--
ALTER TABLE `cdelki`
  MODIFY `id_cdelk` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
  MODIFY `id_client` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `valuts`
--
ALTER TABLE `valuts`
  MODIFY `id_valut` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `cdelki`
--
ALTER TABLE `cdelki`
  ADD CONSTRAINT `cdelki_ibfk_1` FOREIGN KEY (`kod_client`) REFERENCES `clients` (`id_client`),
  ADD CONSTRAINT `cdelki_ibfk_2` FOREIGN KEY (`kod_valuts`) REFERENCES `valuts` (`id_valut`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
