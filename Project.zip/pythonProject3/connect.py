host = 'localhost'
user = 'root'
password = 'root'
db_name = 'dfggf'