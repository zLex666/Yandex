from tkinter import *
from tkinter import ttk
import tkinter as tk
import pymysql
from connect import host, user, password, db_name

connection = pymysql.connect(
    host=host,
    user=user,
    password=password,
    database=db_name,
    cursorclass=pymysql.cursors.DictCursor
)

def table():
    with connection.cursor() as cursor:
        columns = ("kod_client", "kod_valuts", "summa")
        tree = ttk.Treeview(root, columns=columns, show="headings")
        tree.grid(row=10, column=1, columnspan=2, sticky=EW, padx=1, pady=1)
        tree.heading("kod_client", text="Клиент")
        tree.heading("kod_valuts", text="Валюта")
        tree.heading("summa", text="Сумма")
        cur1 = f"SELECT * FROM cdelki,clients,valuts WHERE summa=(SELECT MAX(summa) FROM cdelki) and clients.id_client = cdelki.kod_client AND valuts.id_valut = cdelki.kod_valuts"
        cursor.execute(cur1)
        reess = cursor.fetchall()
        for row in reess:
            a = (row['FIO'])
            b = (row['name'])
            c = (row['summa'])
            d = [(a), (b), (c)]
            tree.insert("", tk.END, values=(d))
        tree.place(x=25, y=15)

def table_vse():
    with connection.cursor() as cursor:
        columns = ("kod_client", "kod_valuts", "summa")
        tree = ttk.Treeview(root, columns=columns, show="headings")
        tree.grid(row=10, column=1, columnspan=2, sticky=EW, padx=1, pady=1)
        tree.heading("kod_client", text="Клиент")
        tree.heading("kod_valuts", text="Валюта")
        tree.heading("summa", text="Сумма")
        cur2 = f"SELECT * FROM cdelki,clients,valuts where clients.id_client = cdelki.kod_client AND valuts.id_valut = cdelki.kod_valuts"
        cursor.execute(cur2)
        rees = cursor.fetchall()
        for row in rees:
            a = (row['FIO'])
            b = (row['name'])
            c = (row['summa'])
            d = [(a), (b), (c)]
            tree.insert("", tk.END, values=(d))
        tree.place(x=25, y=15)

def procent():
    with connection.cursor() as cursor:
        columns = ("Currency", "Share")
        tree = ttk.Treeview(root, columns=columns, show="headings")
        tree.grid(row=10, column=1, columnspan=2, sticky=EW, padx=1, pady=1)
        tree.column("Currency", anchor=CENTER, width=300)
        tree.column("Share", anchor=CENTER, width=300)
        tree.heading("Currency", text="Валюта")
        tree.heading("Share", text="Процент")
        cursor.execute(
            "SELECT SUM(summa * kurs_sales) as total_sum FROM cdelki, valuts WHERE cdelki.kod_valuts = valuts.id_valut")
        total_sum = cursor.fetchone()['total_sum']
        cursor.execute(
            "SELECT name, SUM(summa * kurs_sales) / %s * 100 as share FROM cdelki, valuts WHERE cdelki.kod_valuts = valuts.id_valut GROUP BY name",
            (total_sum,))
        result = cursor.fetchall()
        for row in result:
            a = (row['name'])
            b = (row['share'])
            d = [(a), (b)]
            tree.insert("", tk.END, values=(d))
        tree.place(x=25, y=15)

root = Tk()
root.title('Обменник валют')
root.geometry('650x315+650+300')
root.configure(background='#B8B886')

bt1 = Button(root, text='Все сделки', font="Times", background='#9898F5',
                activebackground='#d8aee8', activeforeground='white', width=14, relief=RIDGE, height=2, command=table_vse, bd=3)
bt1.place(x=90, y=250)

bt3 = Button(root, text='Максимальная сделка', font="Times", background='#9898F5',
                activebackground='#d8aee8', activeforeground='white', width=18, relief=RIDGE, height=2, command=table, bd=3)
bt3.place(x=250, y=250)

bt3 = Button(root, text='Доля по валютам', font="Times", background='#9898F5',
                activebackground='#d8aee8', activeforeground='white', width=14, relief=RIDGE, height=2, command=procent, bd=3)
bt3.place(x=440, y=250)

root.mainloop()